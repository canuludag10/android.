package com.example.deneme2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Bilmeceler"); // toolbar başlığını değiştirir
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) { // Menu ıtem tıklama olayını yakalamak için
        if (item.getItemId()==R.id.id_ayarlar){
            startActivity(new Intent(getApplicationContext(),AyarlarActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { // Menu oluşturmakiçin kullanılır
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }



}
